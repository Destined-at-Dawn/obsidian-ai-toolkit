---
name: scaffold-workspace
description: |
  一键生成符合{{USER_NAME}}标准的工作区/项目脚手架。
  触发词（高敏感，任意匹配即触发）：
  - 明确意图：新建工作区、新建项目、初始化、scaffold、脚手架、创建项目模板、工作区模板、项目模板
  - 口语化表达：开个新项目、搞个新工作区、建一个项目、新开个xxx、我想做一个xxx项目、我准备开始xxx了
  - 隐含意图：这个事情我要长期做、这个我要持续跟进、帮我建个xxx目录、我需要一个专门的xxx空间、这个要转为长期项目、帮我搞个xxx的管理
  - 场景触发：用户开始一个全新领域/方向/任务，且当前工作区没有对应目录时，主动提示是否需要创建
  - 配合触发：用户说了"长期放养/长期项目/长期跟进/转为项目/拆解为任务"等 convert_to_project 相关词时，同时考虑是否需要 scaffold 先建好目录结构
  核心能力：根据用户需求，自动生成 CLAUDE.md + memory/ 三层记忆体系 + project.md + 归档目录 + 自我进化目录 + SOPs/ 等全套文件，确保每个新工作区/项目从第一天就符合「牛马AI生态系统」的全部规范。
---

# Scaffold Workspace — 工作区/项目一键脚手架生成器

> 从 {{CLAUDE_COUNT}} 个 CLAUDE.md、{{MEMORY_COUNT}} 个 memory 文件、14 个 project.md 中提炼的最佳实践结晶。
> 每次生成都基于元模板，确保零偏差、零遗漏。

---

## 核心概念

**工作区（Workspace）** = 独立的牛马AI项目空间，如「创作」「求职」「个人」「竞赛」
- 路径模式：`{{WORKSPACE_ROOT}}\{工作区名}\{工作区名}\`（双层嵌套！）
- 每个工作区有独立的 CLAUDE.md、memory/、projects/、归档/、自我进化/

**项目（Project）** = 工作区内的子项目，如「科研日报」「FPGA_LCD驱动」
- 路径模式：`{工作区路径}/projects/{proj-id}\` 或 `{工作区路径}/{项目名}\`
- 项目可以有独立的 CLAUDE.md、memory/、SOPs/、project.md

---

## 触发判定规则（AI 必读）

### 何时主动触发此 skill

以下场景**必须主动调用此 skill**，不需要用户说出精确触发词：

1. **用户提到"新项目/新方向/新领域"** — 即使没说"创建"，只要意图是开始新事物
   - ✅ "我最近要开始学ROS了" → 询问是否创建项目
   - ✅ "我想搞一个xxx" → 询问是否创建项目
   - ✅ "帮我弄一个xxx的管理" → 询问是否需要完整工作区还是子项目

2. **用户描述了一个需要持续跟进的事情**
   - ✅ "这个比赛我要参加" → 询问是否在{{WS_4_NAME}}区创建子项目
   - ✅ "我接了个xxx的活" → 询问是否创建项目

3. **用户说"长期放养/长期项目/长期跟进/转为项目"等词**
   - ✅ 先问是否需要 scaffold 建目录结构，再用 convert_to_project

4. **用户的工作区里缺少标准结构**
   - ✅ 如果用户在一个已有的目录里工作，但该目录没有 CLAUDE.md 或 memory/ → 主动提示补建

5. **用户说"模板/模板化/标准化/规范化"某个流程**

### 不触发的情况

- 用户只是随口提到某个话题，没有持续跟进意图
- 用户明确说"不需要项目管理"或"只是聊聊"
- 用户已经在对应的项目/工作区对话中，且结构已完整

### 判断不清时

**默认倾向触发** — 宁可多问一句"是否需要创建项目结构"，也不要漏掉。用 AskUserQuestion 询问，用户可以轻松拒绝。

---

## Phase 0：需求判断（必做，不可跳过）

用户提供输入后，**第一步判断类型**：

| 类型 | 特征 | 处理流程 |
|------|------|---------|
| **A. 新建工作区** | 全新的领域/方向，不属于现有四大工作区 | → Phase 1A |
| **B. 新建项目（已有工作区内）** | 在现有工作区（创作/求职/个人/竞赛）内新建子项目 | → Phase 1B |
| **C. 新建对话（已有工作区内）** | 只需要新建一个对话，不需要完整的项目结构 | → 告知用户不需要此skill |

**判断不清时，用 AskUserQuestion 问用户。**

---

## Phase 1A：新建工作区全流程

### Step 1：收集工作区信息

用 AskUserQuestion 依次询问（如果用户一次说全了，跳过已知信息）：

1. **工作区名称**（中文，如「科研」「创业」「留学」）
2. **工作区定位**（一句话描述这个工作区做什么）
3. **领域类型**（决定 CLAUDE.md 的领域专属规则）

```
领域类型选择：
- 内容创作型（公众号/小红书/博客/视频）→ 参考{{WS_1_NAME}}区模板
- 求职就业型（简历/面试/实习/求职）    → 参考{{WS_2_NAME}}区模板
- 竞赛项目型（比赛/课题/工程项目）      → 参考{{WS_4_NAME}}区模板
- 个人成长型（学习/认知/习惯/成长）      → 参考{{WS_3_NAME}}区模板
- 自定义混合型                          → 使用通用基础模板 + 自选模块
```

4. **是否需要以下模块**（默认全选，用户可以排除）：
   - [ ] 百大认知引用铁律（引用{{WS_3_NAME}}区 {{BOOK_COUNT}} 本书）
   - [ ] SOP 系统（标准操作流程）
   - [ ] Skill 路由系统（技能自动匹配）
   - [ ] 消息路由索引（10秒判断该读什么）
   - [ ] Pattern-Key 防重犯体系
   - [ ] 每日完成记录系统
   - [ ] 提示词管理（视觉/文本）
   - [ ] 个人信息同步（telos）

### Step 2：生成文件

根据收集的信息，按以下清单**逐个生成**每个文件，每生成一个必须 Read 验证：

**目录结构（必须全部创建）：**

```
{{WORKSPACE_ROOT}}\{工作区名}\{工作区名}\
├── CLAUDE.md                                    ← [§A] 全局约束文件
├── memory\                                      ← 目录
│   ├── MEMORY.md                                ← [§B] 记忆总索引
│   └── long-term.md                             ← [§C] 长期记忆
├── projects\                                    ← 目录（空的，后续项目放这里）
├── 归档\                                        ← 目录（双归档铁律）
├── 自我进化\                                    ← 目录
│   ├── 做得好的鼓励\                             ← 目录
│   └── 做得差的避免\                             ← 目录
├── SOPs\                                        ← 目录（如果选了SOP模块）
│   └── SOP总索引.md                             ← [§E] SOP总索引（如选了SOP模块）
├── conversations\                               ← 目录（对话记录归档）
└── .claude\                                     ← 目录（可选，skill-rules.json）
    └── skill-rules.json                         ← [§D] Skill路由规则（如果选了Skill模块）
```

**文件生成顺序和来源模板：**

| # | 文件 | 模板来源 | 说明 |
|---|------|---------|------|
| 1 | `CLAUDE.md` | `templates/claude-md/_base.md` + 领域模板拼接 | 核心约束文件，最复杂 |
| 2 | `memory/MEMORY.md` | `templates/memory/MEMORY.md` | 记忆索引 |
| 3 | `memory/long-term.md` | `templates/memory/long-term.md` | 长期记忆 |
| 4 | `SOPs/SOP总索引.md` | `templates/sops/domain-{类型}.md` | SOP总索引（如选了SOP模块，**必生成**） |
| 5 | `SOPs/{NN}_{名称}SOP.md` ×N | `templates/sops/domain-{类型}.md` + `templates/memory/sop.md` | 核心SOP文件（如选了SOP模块，**必生成，不许空目录**） |
| 6 | `SOPs/个人信息同步SOP.md` | 共享SOP路由入口 | 所有工作区通用 |
| 7 | `.claude/skill-rules.json` | 按需，参考{{WS_1_NAME}}区格式 | Skill路由 |

**SOP生成流程（如用户选了SOP模块）：**

> **铁律：SOP模块选了就必须生成SOP文件，不能只建空目录。**

**Step 1：读取领域SOP起手包**

根据领域类型，读取对应的起手包（含所有核心SOP骨架）：
- 创作型 → `templates/sops/domain-creation.md`（4个SOP：输入分发+提示词优化+内容创作+个人信息同步）
- 求职型 → `templates/sops/domain-jobseeking.md`（3个SOP：简历生成+面试复盘+企业定制）
- 竞赛型 → `templates/sops/domain-competition.md`（4个SOP：代码理解+竞赛全流程+硬件设计+个人信息同步）
- 个人型 → `templates/sops/domain-personal.md`（4个SOP：学习加速+费曼检验+复盘分析+人生规划）
- 自定义型 → 从以上4个中按需组合

**Step 2：生成 SOP总索引.md**

读取统一SOP模板 `{{WORKSPACE_ROOT}}\mutual\mutual\sop-template.md` 中的「SOP总索引模板」，填充：
- 工作区名、SOP总数、最后更新日期
- SOP清单表（编号/名称/文件/触发条件/状态）
- 消息路由规则（从领域起手包的触发条件提取）

**Step 3：逐个生成核心SOP文件**

从领域起手包中提取每个SOP骨架，按以下流程生成：
1. 读取通用SOP模板 `templates/memory/sop.md` 获取标准格式
2. 将起手包中的SOP骨架内容填入模板
3. 替换所有占位符（`{{工作区名}}`、`{{当前日期}}` 等）
4. 根据工作区具体情况补充细节
5. Write 写入 `SOPs/{文件名}` → Read 验证

**Step 4：生成个人信息同步SOP路由（所有工作区通用）**

无论什么领域类型，都必须生成 `SOPs/个人信息同步SOP.md`，内容为路由入口：
- 引用共享路径 `cross-workspace-sync/shared-rules/sop-personal-info-sync.md`
- 包含快速参考表（信号类型→telos文件映射）

**Step 5：验证**

- 确认 SOPs/ 目录下文件数量 = SOP总索引中列出的数量
- 确认每个SOP文件都 Read 验证过
- 确认无残留占位符

**生成 CLAUDE.md 的详细流程：**

1. 读取 `templates/claude-md/_base.md`（通用基础骨架）
2. 根据领域类型，读取对应的领域模板：
   - 创作型 → `templates/claude-md/workspace-creation.md`
   - 求职型 → `templates/claude-md/workspace-jobseeking.md`
   - 竞赛型 → `templates/claude-md/workspace-competition.md`
   - 个人型 → `templates/claude-md/workspace-personal.md`
3. 按用户选择的模块，从领域模板中提取对应章节
4. 将通用骨架 + 领域章节 + 用户配置信息拼接成完整的 CLAUDE.md
5. 替换所有占位符（`{{工作区名}}`、`{{工作区路径}}`、`{{版本号}}` 等）
6. Write 写入 → Read 验证

### Step 3：生成后报告

输出：

```
✅ 工作区创建完成

📁 工作区路径：{{WORKSPACE_ROOT}}\{工作区名}\{工作区名}\
📄 生成的文件：
  - CLAUDE.md ({行数}行, v1.0)
  - memory/MEMORY.md
  - memory/long-term.md
  - 归档/ (空目录)
  - 自我进化/做得好的鼓励/_模板_成功案例.md (基于 self-evolution-success.md 模板)
  - 自我进化/做得差的避免/_模板_失败教训.md (基于 self-evolution-failure.md 模板)
  - projects/ (空目录)
  - SOPs/SOP总索引.md ({行数}行)
  - SOPs/{每个SOP文件名}.md ×{N}个（全部Read验证通过）
  - SOPs/个人信息同步SOP.md（共享路由入口）
  - conversations/ (空目录)
  - .claude/skill-rules.json (如选了Skill模块)

🔧 已启用模块：{模块列表}
📋 SOP清单：{SOP数量}个SOP（详见SOPs/SOP总索引.md）
⏭️ 下一步：可以用「新建项目」在此工作区内创建子项目
```

---

## Phase 1B：新建项目（已有工作区内）全流程

### Step 1：确认工作区

用 AskUserQuestion 询问：
1. **在哪个工作区？**（创作/求职/个人/竞赛/其他）
2. **项目名称**（中文或英文，如「ROS学习」「公众号自动化」）
3. **项目类型**：
   - 长期放养项目（需要完整的三层记忆 + SOP + 自我进化）
   - 短期任务项目（只需要 project.md + 基础 memory）
   - 纯技术项目（需要 CLAUDE.md 技术约束 + 输出目录）
4. **是否需要独立 CLAUDE.md**（大多数子项目需要）

### Step 2：生成项目文件

**项目 ID 生成规则：** `proj-{13位时间戳}-{5位随机ID}`（参考现有项目格式）

**目录结构：**

```
{工作区路径}/projects/{proj-id}/
├── CLAUDE.md                                    ← [§E] 项目级约束（如需要）
├── project.md                                   ← [§F] 项目计划/里程碑
├── memory\                                      ← 目录
│   ├── MEMORY.md                                ← 项目记忆索引（长期放养型）
│   ├── long-term.md                             ← 项目长期记忆
│   └── {YYYY-MM-DD}.md                          ← 今天的日期记忆
├── SOPs\                                        ← 目录（长期放养型）
├── outputs\                                     ← 目录（产出文件）
├── 归档\                                        ← 目录
└── 自我进化\                                    ← 目录（长期放养型）
    ├── 做得好的鼓励\_模板_成功案例.md            ← 基于 self-evolution-success.md 模板
    └── 做得差的避免\_模板_失败教训.md            ← 基于 self-evolution-failure.md 模板
```

**文件生成：**

| # | 文件 | 模板来源 |
|---|------|---------|
| 1 | `project.md` | `templates/memory/project.md` |
| 2 | `CLAUDE.md` | `templates/claude-md/project.md` |
| 3 | `memory/MEMORY.md` | `templates/memory/MEMORY.md` |
| 4 | `memory/long-term.md` | `templates/memory/long-term.md` |
| 5 | `memory/{今天日期}.md` | `templates/memory/date-file.md` |

### Step 3：生成后报告

类似 Phase 1 Step 3 的格式。

---

## 铁律（必须遵守）

### 1. 路径铁律
- 所有工作区必须是双层嵌套：`{{WORKSPACE_ROOT}}\{名}\{名}\`
- **禁止**写入外层目录（如 `{{WORKSPACE_ROOT}}\{名}\` 只是容器）
- 项目 ID 使用 `proj-{timestamp}-{random}` 格式

### 2. 文件操作铁律
- 每个文件生成后**必须 Read 验证**
- 禁止生成空文件或占位符文件
- 所有 CLAUDE.md 必须包含变更记录表

### 3. 模板铁律
- 所有生成必须基于元模板（`templates/` 目录内的文件）
- 禁止凭空编写——必须先读模板、再定制
- 占位符统一用 `{{变量名}}` 格式

### 4. 双归档铁律
- 每个工作区/项目都必须有 `归档/` 目录
- 全局归档路径：`{{WORKSPACE_ROOT}}\归档\`

### 5. 跨工作区同步铁律
- 个人信息单一真相源：`{{TELOS_PATH}}\`
- 百大认知书籍单一真相源：`{{WORKSPACE_ROOT}}\个人\个人\百大认知书籍\`
- 新工作区的 CLAUDE.md 必须声明与其他工作区的关系

### 6. 禁止覆盖铁律
- 生成前必须检查目标路径是否已有同名文件
- 如果已有文件 → 用 AskUserQuestion 询问用户是覆盖、合并还是跳过

---

## 变量占位符清单

生成时必须替换以下占位符：

| 占位符 | 说明 | 示例 |
|--------|------|------|
| `{{工作区名}}` | 工作区中文名 | 创作 |
| `{{工作区路径}}` | 工作区完整路径 | {{WORKSPACE_ROOT}}\创作\创作 |
| `{{工作区定位}}` | 一句话定位 | 公众号/小红书/朋友圈内容创作体系 |
| `{{版本号}}` | 初始版本 | v1.0 |
| `{{当前日期}}` | 创建日期 | 2026-05-09 |
| `{{项目名}}` | 项目名称 | 科研日报系统 |
| `{{项目ID}}` | 项目标识 | proj-1777084456942-plvse9 |
| `{{领域类型}}` | 创作/求职/竞赛/个人 | 创作 |
| `{{领域模板名}}` | 对应领域模板文件名 | workspace-creation |
| `{{模块列表}}` | 用户选择的模块 | 百大认知引用, SOP系统, 消息路由 |
| `{{全局归档路径}}` | 固定值 | {{WORKSPACE_ROOT}}\归档 |

---

## 技能组成员（Skill Group Membership）

本技能属于 **Workspace Builder（工作区构建组）**，是该组的 Step 1（主技能）。

### 执行链路

```
Step 1: scaffold-workspace（本技能）→ 生成全套文件
  ↓ 完成后自动触发
Step 2: cross-workspace-sync → 检查新区是否需要同步共享规则
  ↓ 完成后自动触发
Step 3: three-tier-memory → 写入第一条事件："新工作区 {名称} 已创建"
  ↓ 对话结束时
Step 4: session-summary → 输出完整构建报告（替代普通审计）
```

### 联动触发规则

```
当本技能完成（Step 3 生成报告输出后）：
1. 自动询问用户："新区是否需要同步共享规则？（文件操作铁律、双归档铁律等）"
2. 如果用户同意 → 触发 cross-workspace-sync Phase 1
3. sync 完成后 → 自动触发 three-tier-memory 写入创建事件
4. 整个过程记入 session_calls 列表

如果用户在 scaffold 过程中透露了个人信息：
→ cross-workspace-sync R08 同时静默触发（并行，不阻塞 scaffold 主流程）
```

### 技能组协调协议引用

完整协议见：`{{WORKSPACE_ROOT}}\mutual\mutual\skill-group-protocol.md`

---

## 完成标志

一次完整的脚手架生成 = 以下全部完成：

1. **用户确认了需求**（Phase 0 + Step 1 的 AskUserQuestion）
2. **所有目录创建成功**（mkdir -p 验证）
3. **所有文件生成并 Read 验证**（✅ 已验证: {路径} — {行数}行）
4. **占位符全部替换**（无残留的 `{{xxx}}`）
5. **输出生成报告**（文件清单 + 下一步建议）
