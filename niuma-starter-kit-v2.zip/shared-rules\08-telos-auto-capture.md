<!--
共享规则 R08：telos 个人信息自动捕获
同步范围：所有工作区（必须植入每个 CLAUDE.md）
变量：无
设计目的：让 AI 在每次对话中自动监听个人信息变更，无需用户主动提醒
-->

# R08 — telos 个人信息自动捕获（真源 v1.1，高敏感度）

> **核心理念**：用户不应该记住"我需要告诉AI去更新telos"。AI应该自己捕捉、自己更新。
> **宁可多存一条，也不要漏存一条。存错了用户可以删，漏存了信息就丢了。**
> 此规则必须植入每个工作区的 CLAUDE.md。

---

## 标准文本（植入 CLAUDE.md 的规则段落）

### 自动捕获触发器（高敏感度）

> **每次对话中，AI 必须在后台持续监听以下信号。一旦检测到，立即静默更新 telos（无需告知用户，除非涉及敏感信息确认）。**
> **默认倾向：宁可多捕获，不要漏捕获。判断不清时，执行捕获。**

#### 触发信号表（11 类信号，覆盖用户个人信息的所有维度）

| 信号类型 | 用户说了什么（示例，不限于此） | 更新哪个 telos 文件 | 更新方式 |
|---------|-------------------------------|-------------------|---------|
| **身份信息** | "我叫xxx"/"我是xxx学校的"/"我xx年出生"/"我的学号是"/"我转专业了"/"我大二了" | identity.md | 修改对应字段 |
| **联系方式** | "我的电话是xxx"/"新号码"/"我的邮箱是xxx"/"我的github是xxx" | identity.md | 追加/修改（**需确认**） |
| **考试成绩** | "我GPA是xxx"/"我考了xxx分"/"我过了四级"/"四级xxx分"/"我拿到了xxx证书" | identity.md | 追加/修改 |
| **目标调整** | "我打算xxx"/"我的目标是"/"我想考xxx"/"不想考研了"/"想试试XX"/"我计划xxx" | goals.md | 修改对应目标 |
| **新兴趣** | "最近在看XX"/"对XX感兴趣"/"开始学XX"/"我开始关注xxx"/"我想学xxx" | interests.md | 追加到对应分类 |
| **新技能** | "学会了XX"/"在用XX工具"/"能做XX了"/"我掌握了xxx"/"我搞定xxx了" | skills.md | 追加到对应分类 |
| **认知跃迁** | "我觉得XX才是对的"/"原来XX不是这样"/"我认为xxx应该xxx"/"我发现xxx" | beliefs.md 或 insights.md | 追加到对应分类 |
| **偏好/教训** | "以后不要XX"/"我更喜欢XX"/"你别再xxx了"/"你又犯了xxx"/"以后要xxx" | learned.md | 追加或修改 |
| **经历事件** | "我参加了xxx"/"拿到了XX"/"XX通过了"/"我获得了xxx"/"xxx比赛结果出来了" | experiences.md | 追加条目 |
| **人脉关系** | "我导师是xxx"/"认识了XX老师"/"XX推荐了XX"/"xxx老师让我xxx" | identity.md → 指导老师 | 追加条目 |
| **心理状态** | "我最近压力很大"/"我焦虑xxx"/"我担心xxx"/"我对xxx有把握了" | work-style.md 或 learned.md | 追加条目 |

#### 捕获流程（后台静默执行）

```
用户消息中检测到个人信息信号
    ↓
判断：这是新信息还是已知信息？
    ↓
新信息 → Read telos 对应文件 → Edit 追加新条目 → Read 验证
已知信息但有变化 → Read → Edit 修改旧条目 → Read 验证
已知且无变化 → 跳过
    ↓
（如果是敏感信息：电话/身份证/密码）→ AskUserQuestion 确认后再写入
```

#### 写入规范

1. **先 Read 再 Edit**（禁止覆盖）
2. **追加格式**：在对应章节末尾追加，带日期前缀
   ```
   - **2026-05-09**：{新信息描述}
   ```
3. **变更记录**：在文件末尾的「变更记录」表中追加一行
4. **Read 验证**：Edit 后必须 Read 确认
5. **敏感信息确认**：电话/身份证/密码/银行卡号 → 必须 AskUserQuestion 确认

#### 写入位置

telos 文件路径：`{{TELOS_PATH}}\`

写入时使用 Bash+Python（因为 telos 在项目目录外部）：

```bash
PYTHONIOENCODING=utf-8 python -c "
import os
fp = os.path.join('{{TELOS_PATH}}', '{filename}.md')
with open(fp, 'r', encoding='utf-8') as f:
    content = f.read()
# 在变更记录表之前插入新内容
marker = '## 变更记录'
if marker in content:
    parts = content.split(marker)
    new_content = parts[0] + '{新内容}\n\n' + marker + parts[1]
else:
    new_content = content + '\n\n' + '{新内容}'
with open(fp, 'w', encoding='utf-8') as f:
    f.write(new_content)
print('OK')
"
```

> 如果 Edit 工具能直接操作 telos 路径（某些环境下可以），则优先用 Edit。
> 只有 Edit 报路径权限错误时，才回退到 Bash+Python。

---

## 批量同步模式

当用户说"同步个人信息"/"更新telos"/"个人信息同步"时，执行完整扫描：

1. 读取所有工作区的 CLAUDE.md 中的用户画像章节
2. 读取所有 memory/long-term.md 中的用户偏好
3. 与 telos 当前内容对比
4. 列出差异清单
5. AskUserQuestion 确认后批量更新

---

## 对话结束自检

每次对话结束前（与 R09 收尾规则联动），自检：

- [ ] 本次对话中用户是否提到了新的个人信息？
- [ ] 如有，是否已更新 telos 对应文件？
- [ ] 是否只更新了本工作区 memory 而忘了更新 telos？
